/*var http = require('http');
    http.createServer(function (req, res) {
      res.writeHead(200, {'Content-Type': 'text/plain'});
      res.end('Hello World\n');
    }).listen(1337, "127.0.0.1");
    console.log('Server running at http://127.0.0.1:1337/');*/


var awsIot = require('aws-iot-device-sdk');
    var device = awsIot.device({
     keyPath: "cert/79b2885f48-private.pem.key",
     certPath: "cert/79b2885f48-certificate.pem.crt",
     caPath: "cert/VeriSign-Class_3-Public-Primary-Certification-Authority-G5.pem",
     clientId: "nexus6",
     region: "us-west-2"
    });

   device
  .on('connect', function() {
    console.log('connect');
    //device.subscribe('things/ee499-projecto');
    device.publish('things/ee499-projecto', JSON.stringify({ test_data: 1}));
    });

device
  .on('message', function(topic, payload) {
    console.log('message', topic, payload.toString());
  });